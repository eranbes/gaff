<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DomainController extends Controller
{
    function index()
    {
        $domains = [
            1 => 'www.mobpals.com'
        ];

        return response($domains, 200);
    }
}
